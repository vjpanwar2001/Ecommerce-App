
import img1 from '../../img/image 106.png'
import img2 from '../../img/image 101.png'
import img3 from '../../img/image 100.png'
import pimg from '../../img/image 1.png'
import pimg2 from '../../img/image 2.png'
import pimg3 from '../../img/image 3.png'
import pimg4 from '../../img/image 4.png'
import pimg5 from '../../img/image 6.png'
import pimg6 from '../../img/image 7.png'
import pimg7 from '../../img/Images (1).png'
import pimg8 from '../../img/Images.png'


export let bdata = [
        {
            'heading':'Dining',
            'img':img1
        },
        {
            'heading':'Living',
            'img':img3
        },
        {
            'heading':'Beadroom',
            'img':img2
        },
    ]

export let products = [
    {
        'pimg': pimg,
        'phead':"Demo1",
        'des':'This Is Demo Product',
        'saleprice':'Rs 500',
        'regularprice':'Rs 1000'
    },
    {
        'pimg': pimg2,
        'phead':"Demo2",
        'des':'This Is Demo Product',
        'saleprice':'Rs 300',
        'regularprice':'Rs 500'
    },
    {
        'pimg': pimg3,
        'phead':"Demo3",
        'des':'This Is Demo Product',
        'saleprice':'Rs 2000',
        'regularprice':'Rs 7000'
    },
    {
        'pimg': pimg4,
        'phead':"Demo4",
        'des':'This Is Demo Product',
        'saleprice':'Rs 350',
        'regularprice':'Rs 650'
    },
    {
        'pimg': pimg5,
        'phead':"Demo5",
        'des':'This Is Demo Product',
        'saleprice':'Rs 543',
        'regularprice':'Rs 768'
    },
    {
        'pimg': pimg6,
        'phead':"Demo6",
        'des':'This Is Demo Product',
        'saleprice':'Rs 444',
        'regularprice':'Rs 666'
    },
    {
        'pimg': pimg7,
        'phead':"Demo7",
        'des':'This Is Demo Product',
        'saleprice':'Rs 245',
        'regularprice':'Rs 345'
    },
    {
        'pimg': pimg8,
        'phead':"Demo8",
        'des':'This Is Demo Product',
        'saleprice':'Rs 245',
        'regularprice':'Rs 345'
    },

    
]