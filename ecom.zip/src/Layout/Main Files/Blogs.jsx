import React from 'react'
import Header from '../Common Files/Header'

function Blogs() {
  return (
    <>
    <Header/>
  </>
  )
}

export default Blogs