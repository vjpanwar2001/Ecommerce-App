import React from 'react'
import Header from '../Common Files/Header'

function Contact() {
  return (
    <>
      <Header/>
    </>
  )
}

export default Contact